import com.cycling74.max.*;
import java.util.HashMap;
import java.util.Iterator;

public class NoteBuffer extends MaxObject
{

	private static final String[] INLET_ASSIST = new String[]{
		"inlet 1 help"
	};
	private static final String[] OUTLET_ASSIST = new String[]{
		"outlet 1 help"
	};

	private HashMap<Integer,Integer> addedPitches;
	
	public NoteBuffer(Atom[] args)
	{
		declareInlets(new int[]{DataTypes.ALL});
		declareOutlets(new int[]{DataTypes.ALL});
		
		setInletAssist(INLET_ASSIST);
		setOutletAssist(OUTLET_ASSIST);

		addedPitches = new HashMap<Integer,Integer>();

	}
    
	public void bang()
	{
	}
    
	public void inlet(int i)
	{
	}
    
	public void inlet(float f)
	{
	}
    
    
	public synchronized void list(Atom[] list)
	{
		int velocity = list[1].getInt();
		int pitch = list[0].getInt();
		if (velocity != 0 && !this.addedPitches.containsKey(pitch)) {
			int numberOfAddedPitches = 2;
			//int numberOfAddedPitches = (int)Math.floor(Math.pow(1.5*Math.random(),4));
			for (int i = 1; i <= numberOfAddedPitches; i++) {
				int addedPitch = pitch+(int)Math.ceil(i*6*Math.random());
				this.addedPitches.put(addedPitch, pitch);
				outlet(0, new Atom[]{Atom.newAtom(addedPitch), Atom.newAtom(velocity)});
			}
		} else if (velocity == 0 && this.addedPitches.containsValue(pitch)) {
			Iterator<Integer> addedPitchesItr = this.addedPitches.keySet().iterator();  
  			while (addedPitchesItr.hasNext()) {
				int currentAddedPitch = addedPitchesItr.next(); 
				if (this.addedPitches.get(currentAddedPitch) == pitch) {
					addedPitchesItr.remove();
					this.addedPitches.remove(currentAddedPitch);
					outlet(0, new Atom[]{Atom.newAtom(currentAddedPitch), Atom.newAtom(0)});
				}
			}
		}
		post(pitch + " " + this.addedPitches.keySet().toString());
	}
    
}










