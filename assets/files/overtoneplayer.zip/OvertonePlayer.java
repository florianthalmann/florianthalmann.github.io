import com.cycling74.max.*;
import java.util.*;

public class OvertonePlayer extends MaxObject {

	private static final String[] INLET_ASSIST = new String[] {
		"inlet 1 help"
	};
	private static final String[] OUTLET_ASSIST = new String[] {
		"outlet 1 help"
	};

	private Set<Integer> basePitches;
	private List<Set<Integer>> score;
	
	private static final int frameLength = 500;
	private static final int basePitchDuration = 500;
	private static final int decayBeforeRecording = 500;
	
	public OvertonePlayer(Atom[] args) {
		declareInlets(new int[]{DataTypes.ALL});
		declareOutlets(new int[]{DataTypes.ALL, DataTypes.ALL});
		
		setInletAssist(INLET_ASSIST);
		setOutletAssist(OUTLET_ASSIST);

		this.basePitches = new HashSet<Integer>(Arrays.asList(24));
		
		this.score = new ArrayList<Set<Integer>>();
		this.score.add(new HashSet<Integer>(Arrays.asList(60, 64, 67)));
		this.score.add(new HashSet<Integer>(Arrays.asList(62, 63, 67)));
		this.score.add(new HashSet<Integer>(Arrays.asList(61, 65, 67)));
		this.score.add(new HashSet<Integer>(Arrays.asList(62, 65, 67)));

	}
    
	public void bang() {
		Set<Integer> currentOvertones = new HashSet<Integer>();
		try {
			for (int i = 0; i < this.score.size(); i++) {
				currentOvertones = this.score.get(i);
				this.playPitches(currentOvertones, 127);
				this.playPitches(this.basePitches, 127);
				Thread.sleep(OvertonePlayer.basePitchDuration);
				this.playPitches(this.basePitches, 0);
				Thread.sleep(OvertonePlayer.decayBeforeRecording);
				this.triggerRecording();
				this.playPitches(currentOvertones, 0);
			}
		} catch (java.lang.InterruptedException err) {
			this.playPitches(currentOvertones, 0);
			this.playPitches(this.basePitches, 0);
		}
	}
		
	private void playPitches(Set<Integer> pitches, int velocity) {
		Iterator<Integer> pitchIterator = pitches.iterator();
		while (pitchIterator.hasNext()) {
			outlet(0, new Atom[]{Atom.newAtom(pitchIterator.next()), Atom.newAtom(velocity)});
		}
	}
	
	private void triggerRecording() throws java.lang.InterruptedException {
		outlet(1, 1);
		Thread.sleep(OvertonePlayer.frameLength);
		outlet(1, 0);
	}
    
	public void inlet(int i) {}
    
	public void inlet(float f) {}
    
	public synchronized void list(Atom[] list) {}
    
}