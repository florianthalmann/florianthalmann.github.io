//
//  SettingsViewController.h
//  Valves
//
//  Created by Florian Thalmann on 11/11/08.
//  Copyright 2008 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RootViewController.h"
#import "CheckmarkViewController.h"
#import "ScaleProperties.h"

@interface SettingsViewController : UITableViewController {
	NSMutableArray *options;
	RootViewController *rootViewController;
	ScaleProperties *scaleProperties;
}

@property (nonatomic, retain) NSMutableArray *options;
@property (nonatomic, retain) RootViewController *rootViewController;
@property (nonatomic, retain) ScaleProperties *scaleProperties;

- (UILabel*)createNameLabel:(NSString *)name;
- (UILabel*)createValueLabel:(NSString *)name;

@end
