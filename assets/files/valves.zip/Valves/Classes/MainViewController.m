//
//  MainViewController.m
//  V
//
//  Created by Florian Thalmann on 11/4/08.
//  Copyright __MyCompanyName__ 2008. All rights reserved.
//

#import "MainViewController.h"
#import "Fingerings.h";
#import "FingeringAnalyzer.h";
#import "ScoreList.h";
#import "Scale.h";

@implementation MainViewController

@synthesize previousFingering;
@synthesize fingerings;
@synthesize infoLabel;
@synthesize resetButton;
@synthesize valve1Button;
@synthesize valve2Button;
@synthesize valve3Button;
@synthesize analyzer;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
		fingerings = [[Fingerings alloc] init];
        [self resetFields];
    }
    return self;
}


/*
// Implement viewDidLoad to do additional setup after loading the view.
- (void)viewDidLoad {
    [super viewDidLoad];
}
*/

- (void)resetFields {
	previousTime = 0;
	previousFingering = nil;
}


- (void)updateScale:(Scale *)scale database:(sqlite3 *)database {
	NSArray *pitches = [scale pitches];
	
	/*NSString *scaleString = @"";
	for (int i = 0; i < [pitches count]; i++) {
		NSString *currentPitch = [NSString stringWithFormat:@"%i ", [[pitches objectAtIndex:i] intValue]];
		scaleString = [scaleString stringByAppendingString:currentPitch];
	}*/
	
	NSArray *scaleFingerings = [fingerings translatePitchesToFingerings:pitches];
	analyzer = [[FingeringAnalyzer alloc] initWithScale:scaleFingerings parentController:self];
	scoreList = [[ScoreList alloc] initWithScale:scale database:database];
	[self resetButtonPressed];
}


- (IBAction)resetButtonPressed {
	[analyzer reset];
	[self resetFields];
	[[self view] setBackgroundColor:[UIColor colorWithWhite:0.25 alpha:1]];
	infoLabel.text = [scoreList stringValue];
	[self valvesEnabled:YES];
}

- (IBAction)valveButtonReleased:(id)sender {
	if (valvesEnabled) {
		double currentTime = [NSDate timeIntervalSinceReferenceDate];
		if (previousTime != 0 && previousFingering != nil) {
			double previousTimeInterval = currentTime - previousTime;
			[analyzer fingeringPlayed:previousFingering forTime:previousTimeInterval];
		}
		BOOL v1 = [valve1Button isTouchInside] && sender != valve1Button;
		BOOL v2 = [valve2Button isTouchInside] && sender != valve2Button;
		BOOL v3 = [valve3Button isTouchInside] && sender != valve3Button;
		previousFingering = [fingerings getFingeringFor:v1 and:v2 and:v3];
		previousTime = currentTime;
	}
}

- (IBAction)valveButtonPressed:(id)sender {
	double currentTime = [NSDate timeIntervalSinceReferenceDate];
	if (previousTime != 0 && previousFingering != nil) {
		double previousTimeInterval = currentTime - previousTime;
		[analyzer fingeringPlayed:previousFingering forTime:previousTimeInterval];
	}
	BOOL v1 = [valve1Button isTouchInside];
	BOOL v2 = [valve2Button isTouchInside];
	BOOL v3 = [valve3Button isTouchInside];
	previousFingering = [fingerings getFingeringFor:v1 and:v2 and:v3];
	previousTime = currentTime;
}


- (void)showPlayingMistake {
	[[self view] setBackgroundColor:[UIColor colorWithRed:0.5 green:0 blue:0 alpha:1]];
	[self valvesEnabled:NO];
}


- (void)showSuccessfulPlayingWithBPM:(double)bpm andPrecision:(double)precision {
	[self valvesEnabled:NO];
	NSString *scoreString = [NSString stringWithFormat:@"BPM: %f\nPrecision: %f\n\n", bpm, precision];
	if ([scoreList updateScoreWithBPM:bpm andPrecision:precision]) {
		scoreString = [scoreString stringByAppendingString:@"New record!\n\n"];
		[[self view] setBackgroundColor:[UIColor colorWithRed:0 green:0.5 blue:0 alpha:1]];
	} else {
		scoreString = [scoreString stringByAppendingString:@"Keep on practicing\n\n"];
		[[self view] setBackgroundColor:[UIColor colorWithRed:0 green:0 blue:0.5 alpha:1]];
	}
	infoLabel.text = [scoreString stringByAppendingString:[scoreList stringValue]];
}


- (void)valvesEnabled:(BOOL)enabled {
	valvesEnabled = enabled;
	[valve1Button setEnabled:enabled];
	[valve2Button setEnabled:enabled];
	[valve3Button setEnabled:enabled];
}


- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning]; // Releases the view if it doesn't have a superview
    // Release anything that's not essential, such as cached data
}


- (void)dealloc {
    [super dealloc];
}


@end
