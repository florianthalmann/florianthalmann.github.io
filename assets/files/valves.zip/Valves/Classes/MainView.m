//
//  MainView.m
//  V
//
//  Created by Florian Thalmann on 11/4/08.
//  Copyright __MyCompanyName__ 2008. All rights reserved.
//

#import "MainView.h"

@implementation MainView


- (id)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        // Initialization code
    }
    return self;
}


- (void)drawRect:(CGRect)rect {
    // Drawing code
}


- (void)dealloc {
    [super dealloc];
}


@end
