//
//  MainViewController.h
//  V
//
//  Created by Florian Thalmann on 11/4/08.
//  Copyright __MyCompanyName__ 2008. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <sqlite3.h>
@class Fingerings;
@class FingeringAnalyzer;
@class ScoreList;
@class Scale;

@interface MainViewController : UIViewController {
	BOOL valvesEnabled;
	double previousTime;
	NSArray *previousFingering;
	Fingerings *fingerings;
	FingeringAnalyzer *analyzer;
	ScoreList *scoreList;
    
	UILabel *infoLabel;
	UIButton *resetButton;
	UIButton *valve1Button;
	UIButton *valve2Button;
	UIButton *valve3Button;
}

@property (nonatomic, retain) NSArray *previousFingering;
@property (nonatomic, retain) Fingerings *fingerings;
@property (nonatomic, retain) FingeringAnalyzer *analyzer;
@property (nonatomic, retain) IBOutlet UILabel *infoLabel;
@property (nonatomic, retain) IBOutlet UIButton *resetButton;
@property (nonatomic, retain) IBOutlet UIButton *valve1Button;
@property (nonatomic, retain) IBOutlet UIButton *valve2Button;
@property (nonatomic, retain) IBOutlet UIButton *valve3Button;

- (void)updateScale:(Scale *)scale database:(sqlite3 *)database;
- (void)resetFields;
- (IBAction)resetButtonPressed;
- (IBAction)valveButtonPressed:(id)sender;
- (IBAction)valveButtonReleased:(id)sender;
- (void)showPlayingMistake;
- (void)showSuccessfulPlayingWithBPM:(double)bpm andPrecision:(double)precision;
- (void)valvesEnabled:(BOOL)enabled;

@end
