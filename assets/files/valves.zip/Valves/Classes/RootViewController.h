//
//  RootViewController.h
//  V
//
//  Created by Florian Thalmann on 11/4/08.
//  Copyright __MyCompanyName__ 2008. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <sqlite3.h>
#import "ScaleProperties.h"

@class MainViewController;
@class FlipsideViewController;

@interface RootViewController : UIViewController {

    UIButton *infoButton;
    MainViewController *mainViewController;
    UINavigationController *flipsideViewController;
    UINavigationBar *flipsideNavigationBar;
	ScaleProperties *scaleProperties;
	sqlite3 *database;
}

@property (nonatomic, retain) IBOutlet UIButton *infoButton;
@property (nonatomic, retain) MainViewController *mainViewController;
@property (nonatomic, retain) UINavigationBar *flipsideNavigationBar;
@property (nonatomic, retain) UINavigationController *flipsideViewController;
@property (nonatomic, retain) ScaleProperties *scaleProperties;
@property (nonatomic, assign) sqlite3 *database;

- (IBAction)toggleView;

@end
