//
//  Achievement.h
//  Valves
//
//  Created by Florian Thalmann on 3/15/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <sqlite3.h>


@interface Achievement : NSObject {
	NSString *name;
	double value;
	NSArray *notePatterns;
	NSArray *roots;
	NSArray *intervals;
	NSArray *iterations;
	NSArray *playModes;
	double minimumPrecision;
	int requiredResults;
	sqlite3_stmt *select_statement;
	sqlite3 *database;
}

@property (nonatomic, retain) NSString *name;
@property (nonatomic, assign) double value;

- (id)initWithName:(NSString *)aName andNotePatterns:(NSArray *)somePatterns
		  andRoots:(NSArray *)someRoots andIntervals:(NSArray *)someIntervals
	 andIterations:(NSArray *)someIterations andPlayModes:(NSArray *)somePlayModes
andMinimumPrecision:(double)aPrecision andRequiredResults:(int)numberOfResults andDatabase:(sqlite3 *)db;
- (void)calculateValue;
- (void)prepareStatement;
- (NSString*)appendStringAndClauseFor:(NSArray *)stringArray and:(NSString *)columnString to:(NSString *)sql;
- (NSString*)appendNumberAndClauseFor:(NSArray *)stringArray and:(NSString *)columnString to:(NSString *)sql;

@end
