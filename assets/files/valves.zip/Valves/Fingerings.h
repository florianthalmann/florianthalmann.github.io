//
//  Fingerings.h
//  Valves
//
//  Created by Florian Thalmann on 11/1/08.
//  Copyright 2008 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface Fingerings : NSMutableDictionary {
	NSMutableArray *fingeringsForPitches;
	int lowestPitch;
	NSArray *v0;
	NSArray *v2;
	NSArray *v1;
	NSArray *v12;
	NSArray *v23;
	NSArray *v13;
	NSArray *v123;
}

@property (nonatomic, retain) NSMutableArray *fingeringsForPitches;
@property (nonatomic, retain) NSArray *v0;
@property (nonatomic, retain) NSArray *v2;
@property (nonatomic, retain) NSArray *v1;
@property (nonatomic, retain) NSArray *v12;
@property (nonatomic, retain) NSArray *v23;
@property (nonatomic, retain) NSArray *v13;
@property (nonatomic, retain) NSArray *v123;

- (void)initValveCombinations;
- (void)initFingerings;
- (NSArray*)getFingeringFor:(BOOL)valve1 and:(BOOL)valve2 and:(BOOL)valve3;
- (NSArray*)createValveCombinationWith:(BOOL)valve1 and:(BOOL)valve2 and:(BOOL)valve3;
- (NSArray*)translatePitchesToFingerings:(NSArray *)scale;
- (void)addFingering:(NSArray *)fingering forNote:(int)note;

@end
