//
//  ScaleGenerator.m
//  Valves
//
//  Created by Florian Thalmann on 11/2/08.
//  Copyright 2008 __MyCompanyName__. All rights reserved.
//

#import "ScaleProperties.h"

@implementation ScaleProperties

@synthesize properties;

- (id)init {
	[super init];
	lowestNote = 52;
	SelectableProperty *notePatternProperty = [self initNotePatternProperty];
	SelectableProperty *baseNoteProperty = [self initBaseNoteProperty];
	SelectableProperty *intervalProperty = [self initIntervalProperty];
	SelectableProperty *iterationsProperty = [self initIterationsProperty];
	SelectableProperty *playModeProperty = [self initPlayModeProperty];
	properties = [[NSMutableArray alloc] initWithObjects: notePatternProperty, baseNoteProperty,
				  intervalProperty, iterationsProperty, playModeProperty, nil];
	return self;
}

- (SelectableProperty *)initNotePatternProperty {
	NSMutableArray *patterns = [[NSMutableArray alloc] initWithObjects:
							   @"01", @"02", @"03", @"04", @"05",
								@"012", @"013", @"014", @"015", @"023", @"024", @"025", @"034", @"035", @"045",
								@"0123", @"0124", @"0125", @"0134", @"0135", @"0145", @"0234", @"0235", @"0245", @"0345", nil];
	return [[SelectableProperty alloc] initWithOptionArray:patterns name:@"Pattern"];
}

- (SelectableProperty *)initBaseNoteProperty {
	NSMutableArray *pitches = [[NSMutableArray alloc] initWithObjects:
							   @"F#", @"G", @"G#", @"A", @"Bb", @"B", @"C", nil];
	return [[SelectableProperty alloc] initWithOptionArray:pitches name:@"Base note"];
	//[pitches release];
}

- (SelectableProperty *)initIntervalProperty {
	NSMutableArray *intervals = [[NSMutableArray alloc] initWithObjects:
								 @"1", @"2", @"3", @"4", @"5", @"6", nil];
	return [[SelectableProperty alloc] initWithOptionArray:intervals name:@"Interval"];
}

- (SelectableProperty *)initIterationsProperty {
	NSMutableArray *playModes = [[NSMutableArray alloc] initWithObjects:
								 @"5", @"12", nil];
	return [[SelectableProperty alloc] initWithOptionArray:playModes name:@"Iterations"];
}

- (SelectableProperty *)initPlayModeProperty {
	NSMutableArray *playModes = [[NSMutableArray alloc] initWithObjects:
								 @"012345", @"102132", @"210321", nil];
	return [[SelectableProperty alloc] initWithOptionArray:playModes name:@"Play mode"];
}

- (Scale *)scale {
	NSString *selectedPattern = [[properties objectAtIndex:0] selectedOption];
	int root = lowestNote + [[properties objectAtIndex:1] selectedIndex];
	int interval = [[[properties objectAtIndex:2] selectedOption] intValue];
	int numberOfIterations = [[[properties objectAtIndex:3] selectedOption] intValue];
	NSString *playMode = [[properties objectAtIndex:4] selectedOption];
	return [[Scale alloc] initWithNotePattern:selectedPattern root:root interval:interval 
								   numberOfIterations:numberOfIterations playMode:playMode];
}

@end
