//
//  FingeringAnalyzer.h
//  Valves
//
//  Created by Florian Thalmann on 3/10/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "math.h"
@class MainViewController;
@class Fingerings;

@interface FingeringAnalyzer : NSObject {
	MainViewController *parentController;
	NSArray *scale;
	NSMutableArray *successiveFingerings;
	NSMutableArray *relativeDurations;
	int removedV0InTheBeginning;
	int numberOfFingeringsPlayed;
	NSMutableArray *playedFingerings;
	NSMutableArray *playedDurations;
	int requiredFingeringsForAnalysis;
	//the higher the accuracy value, the shorter the recognized notes can be,
	//i.e. the less accurate you can play but the worse correct recognition will be
	int accuracy;
	int lastIndexOfAnalysis;
}

- (id)initWithScale:(NSArray *)newScale parentController:(MainViewController *)controller;
- (void)initScaleInfo;
- (void)reset;
- (void)fingeringPlayed:(NSArray *)fingering forTime:(double)timeInterval;
- (void)analyze;
- (void)eliminateGlitches;
- (double)getGlitchDuration;
- (BOOL)rightFingeringsPlayed;
- (void)updateDurations;
- (void)postFinalAnalysis;

@end
