//
//  Scale.m
//  Valves
//
//  Created by Florian Thalmann on 3/13/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "Scale.h"

static int highestNote = 84;

@implementation Scale
@synthesize notePattern;
@synthesize root;
@synthesize interval;
@synthesize numberOfIterations;
@synthesize playMode;
@synthesize pitches;

- (id)initWithNotePattern:(NSString *)aNotePattern root:(int)aRoot interval:(int)anInterval
				 numberOfIterations:(int)aNumberOfIterations playMode:(NSString *)aPlayMode {
	notePattern = aNotePattern;
	root = aRoot;
	interval = anInterval;
	numberOfIterations = aNumberOfIterations;
	playMode = aPlayMode;
	[self generate];
	return self;
}

- (void)generate {
	NSMutableArray *generatedPitches = [[NSMutableArray alloc] init];
	NSArray *patternNotes = [self parseIntegers:notePattern];
	for (int i = 0; i < numberOfIterations; i++) {
		for (int j = 0; j < [patternNotes count]; j++) {
			int currentPatternNote = [[patternNotes objectAtIndex:j] intValue];
			int currentPitch = root + i*interval + currentPatternNote;
			if (currentPitch <= highestNote) {
				[generatedPitches addObject:[NSNumber numberWithInt:currentPitch]];
			} else {
				goto done;
			}
		}
	}
done:
	[self appendDescendingMovement:generatedPitches];
	pitches = generatedPitches;
}

- (void)appendDescendingMovement:(NSMutableArray *)pitchArray {
	//generate descending movement
	int secondLastPitch = [pitchArray count]-2;
	for (int i = secondLastPitch; i >= 0; i--) {
		[pitchArray addObject:[pitchArray objectAtIndex:i]];
	}
}

- (NSArray *)parseIntegers:(NSString *)numeralString {
	int n = [numeralString length];
	NSMutableArray *integers = [[NSMutableArray alloc] initWithCapacity:n];
	for (int i = 0; i < n; i++) {
		int currentDigit = [[numeralString substringToIndex:1] intValue];
		[integers addObject:[NSNumber numberWithInt:currentDigit]];
		numeralString = [numeralString substringFromIndex:1];
	}
	return integers;
}

@end
