//
//  ScoreList.h
//  Valves
//
//  Created by Florian Thalmann on 3/13/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <sqlite3.h>
#import "Scale.h"
#import "Score.h"

@interface ScoreList : NSObject {
	Scale *scale;
	sqlite3 *database;
	NSMutableArray *scores;
}

- (id)initWithScale:(Scale *)scale database:(sqlite3 *)db;
- (BOOL)updateScoreWithBPM:(double)bpm andPrecision:(double)precision;
- (void)updateScoreInDB:(Score *)score;
- (void)deleteScoreFromDB:(Score *)score;
- (NSInteger)insertScoreIntoDB:(Score *)score;
- (NSString*)stringValue;

@end
