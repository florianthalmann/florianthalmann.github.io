//
//  SelectableProperty.m
//  Valves
//
//  Created by Florian Thalmann on 11/10/08.
//  Copyright 2008 __MyCompanyName__. All rights reserved.
//

#import "SelectableProperty.h"


@implementation SelectableProperty

@synthesize name;
@synthesize selectedIndex;
@synthesize options;

- (id)initWithOptionArray:(NSMutableArray *)newOptions name:(NSString *)newName {
	self = [super init];
	name = newName;
	options = newOptions;
	self.selectedIndex = 0;
	return self;
}

- (NSString *)selectedOption {
	if (selectedIndex >= 0) {
		return [options objectAtIndex:selectedIndex];
	} else return nil;
}

@end
