//
//  NotePatterns.m
//  Valves
//
//  Created by Florian Thalmann on 3/7/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "NotePatterns.h"


@implementation NotePatterns

- (id)init {
	self = [super init];
	[self initPatterns];
	return self;
}

- (void)initPatterns {
	[self init2NotePatterns];
}

- (void)init2NotePatterns {
	for (int i = 0; i < 5; i++) {
		for (int j = i+1; j < 6; j++) {
			NSNumber *currentI = [NSNumber numberWithInt:i];
			NSNumber *currentJ = [NSNumber numberWithInt:j];
			NSArray *currentPatternArray = [[NSArray alloc] initWithObjects:currentI, currentJ, nil];
			NSString *currentPatternString = [NSString stringWithFormat: @"%i%i", i, j];
			[self addPattern:currentPatternArray withName:currentPatternString];
		}
	}
}

- (void)addPattern:(NSArray *)pattern withName:(NSString *)name {
	[self setObject:pattern forKey:name];
}


@end
