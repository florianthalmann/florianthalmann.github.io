//
//  RootController.h
//  Valves
//
//  Created by Florian Thalmann on 11/4/08.
//  Copyright 2008 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface SettingsController : UITableViewController {

}

@end
