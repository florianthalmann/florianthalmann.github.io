//
//  AchievementsViewController.h
//  Valves
//
//  Created by Florian Thalmann on 3/15/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AchievementList.h"


@interface AchievementsViewController : UITableViewController {
	UITableViewController *parentController;
	AchievementList *achievements;
}

@property (readwrite, retain) UITableViewController *parentController;

- (id)initWithParentController:(UITableViewController *)parent;
- (UILabel*)createNameLabel:(NSString *)name;
- (UILabel*)createValueLabel:(NSString *)name;

@end
