//
//  SelectableProperty.h
//  Valves
//
//  Created by Florian Thalmann on 11/10/08.
//  Copyright 2008 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface SelectableProperty : NSObject {
	NSString *name;
	NSMutableArray *options;
	int selectedIndex;
}

@property (nonatomic, retain) NSString *name;
@property (nonatomic, retain) NSMutableArray *options;
@property (nonatomic, assign) int selectedIndex;

- (id)initWithOptionArray:(NSMutableArray *)newOptions name:(NSString *)newName;
- (NSString *)selectedOption;

@end
