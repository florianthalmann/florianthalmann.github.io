//
//  Achievement.m
//  Valves
//
//  Created by Florian Thalmann on 3/15/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "Achievement.h"


@implementation Achievement

@synthesize name;
@synthesize value;

- (id)initWithName:(NSString *)aName andNotePatterns:(NSArray *)somePatterns
		  andRoots:(NSArray *)someRoots andIntervals:(NSArray *)someIntervals
	 andIterations:(NSArray *)someIterations andPlayModes:(NSArray *)somePlayModes
andMinimumPrecision:(double)aPrecision andRequiredResults:(int)numberOfResults
	   andDatabase:(sqlite3 *)db {
	if (self = [super init]) {
		name = aName;
		notePatterns = somePatterns;
		roots = someRoots;
		intervals = someIntervals;
		iterations = someIterations;
		playModes = somePlayModes;
		minimumPrecision = aPrecision;
		requiredResults = numberOfResults;
		database = db;
	}
	[self calculateValue];
	return self;
}

- (void)calculateValue {
	if (select_statement == nil) {
		[self prepareStatement];
	}
	
	double minimumBPM = 0;
	int resultCount = 0;
	while (sqlite3_step(select_statement) == SQLITE_ROW) {
		double currentBPM = sqlite3_column_double(select_statement, 0);
		double currentPrecision = sqlite3_column_double(select_statement, 1);
		if (currentPrecision > minimumPrecision) {
			if (minimumBPM == 0) {
				minimumBPM = currentBPM;
				resultCount++;
			} else {
				minimumBPM = fmin(currentBPM, minimumBPM);
				resultCount++;
			}
		}
	}
	
	if (resultCount >= requiredResults) {
		value = minimumBPM;
	} else {
		value = 0;
	}
	
	// Reset the statement for future reuse.
	sqlite3_reset(select_statement);
}

- (void)prepareStatement {
	NSString *sql = @"SELECT bpm, precision FROM scores WHERE (";
	sql = [self appendStringAndClauseFor:notePatterns and:@"note_pattern='%@'" to:sql];
	sql = [sql stringByAppendingString:@") AND ("];
	sql = [self appendNumberAndClauseFor:roots and:@"root=%i" to:sql];
	sql = [sql stringByAppendingString:@") AND ("];
	sql = [self appendNumberAndClauseFor:intervals and:@"interval=%i" to:sql];
	sql = [sql stringByAppendingString:@") AND ("];
	sql = [self appendNumberAndClauseFor:iterations and:@"iterations=%i" to:sql];
	sql = [sql stringByAppendingString:@") AND ("];
	sql = [self appendStringAndClauseFor:playModes and:@"play_mode='%@'" to:sql];
	sql = [sql stringByAppendingString:@")"];
	
	if (sqlite3_prepare_v2(database, [sql UTF8String], -1, &select_statement, NULL) != SQLITE_OK) {
		NSAssert1(0, @"Error: failed to prepare statement with message '%s'.", sqlite3_errmsg(database));
	}
}
		
- (NSString*)appendStringAndClauseFor:(NSArray *)array and:(NSString *)columnString to:(NSString *)sql {
	for (int i = 0; i < [array count]; i++) {
		sql = [sql stringByAppendingString:
			   [NSString stringWithFormat:columnString, [array objectAtIndex:i]]];
		if (i < [array count]-1) {
			sql = [sql stringByAppendingString:@" OR "];
		}
	}
	return sql;
}

- (NSString*)appendNumberAndClauseFor:(NSArray *)array and:(NSString *)columnString to:(NSString *)sql {
	for (int i = 0; i < [array count]; i++) {
		sql = [sql stringByAppendingString:
			   [NSString stringWithFormat:columnString, [[array objectAtIndex:i] intValue]]];
		if (i < [array count]-1) {
			sql = [sql stringByAppendingString:@" OR "];
		}
	}
	return sql;
}
	

@end
