//
//  NotePatterns.h
//  Valves
//
//  Created by Florian Thalmann on 3/7/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface NotePatterns : NSMutableDictionary {

}

- (void)initPatterns;
- (void)init2NotePatterns;
- (void)addPattern:(NSArray *)pattern withName:(NSString *)name;

@end
