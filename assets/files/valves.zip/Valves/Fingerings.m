//
//  Fingerings.m
//  Valves
//
//  Created by Florian Thalmann on 11/1/08.
//  Copyright 2008 __MyCompanyName__. All rights reserved.
//

#import "Fingerings.h"


@implementation Fingerings

@synthesize fingeringsForPitches;
@synthesize v0;
@synthesize v2;
@synthesize v1;
@synthesize v12;
@synthesize v23;
@synthesize v13;
@synthesize v123;

- (id)init {
	self = [super init];
	[self initValveCombinations];
	fingeringsForPitches = [[NSMutableArray alloc] init];
	lowestPitch = 52;
	[self initFingerings];
	return self;
}

- (void)initValveCombinations {
	v0 = [self createValveCombinationWith:NO and:NO and:NO];
	v2 = [self createValveCombinationWith:NO and:YES and:NO];
	v1 = [self createValveCombinationWith:YES and:NO and:NO];
	v12 = [self createValveCombinationWith:YES and:YES and:NO];
	v23 = [self createValveCombinationWith:NO and:YES and:YES];
	v13 = [self createValveCombinationWith:YES and:NO and:YES];
	v123 = [self createValveCombinationWith:YES and:YES and:YES];
}

- (void)initFingerings {
	[self addFingering:v123 forNote:52];
	[self addFingering:v13 forNote:53];
	[self addFingering:v23 forNote:54];
	[self addFingering:v12 forNote:55];
	[self addFingering:v1 forNote:56];
	[self addFingering:v2 forNote:57];
	[self addFingering:v0 forNote:58];
	[self addFingering:v123 forNote:59];
	[self addFingering:v13 forNote:60];
	[self addFingering:v23 forNote:61];
	[self addFingering:v12 forNote:62];
	[self addFingering:v1 forNote:63];
	[self addFingering:v2 forNote:64];
	[self addFingering:v0 forNote:65];
	[self addFingering:v23 forNote:66];
	[self addFingering:v12 forNote:67];
	[self addFingering:v1 forNote:68];
	[self addFingering:v2 forNote:69];
	[self addFingering:v0 forNote:70];
	[self addFingering:v12 forNote:71];
	[self addFingering:v1 forNote:72];
	[self addFingering:v2 forNote:73];
	[self addFingering:v0 forNote:74];
	[self addFingering:v1 forNote:75];
	[self addFingering:v2 forNote:76];
	[self addFingering:v0 forNote:77];
	[self addFingering:v23 forNote:78];
	[self addFingering:v12 forNote:79];
	[self addFingering:v1 forNote:80];
	[self addFingering:v2 forNote:81];
	[self addFingering:v0 forNote:82];
	[self addFingering:v12 forNote:83];
	[self addFingering:v1 forNote:84];
}

- (NSArray*)getFingeringFor:(int)midiPitch {
	return [fingeringsForPitches objectAtIndex:midiPitch - lowestPitch];
}

- (NSArray*)getFingeringFor:(BOOL)valve1 and:(BOOL)valve2 and:(BOOL)valve3 {
	if (valve1) {
		if (valve2) {
			if (valve3) {
				return v123;
			} else {
				return v12;
			}
		} else if (valve3) {
			return v13;
		} else {
			return v1;
		}
	} else if (valve2) {
		if (valve3) {
			return v23;
		} else {
			return v2;
		}
	} else if (valve3) {
		return nil; //valve3 alone not a fingering!
	} else {
		return v0;
	}
}

- (NSArray*)translatePitchesToFingerings:(NSArray *)pitches {
	NSMutableArray *pitchFingerings = [[NSMutableArray alloc] initWithCapacity:[pitches count]];
	for (int i = 0; i < [pitches count]; i++) {
		int currentPitch = [[pitches objectAtIndex:i] intValue];
		[pitchFingerings addObject:[fingeringsForPitches objectAtIndex:currentPitch-lowestPitch]];
	}
	return pitchFingerings;
}
		
- (NSArray*)createValveCombinationWith:(BOOL)valve1 and:(BOOL)valve2 and:(BOOL)valve3 {
	return [[NSArray alloc] initWithObjects: [NSNumber numberWithBool:valve1],
			[NSNumber numberWithBool:valve2], [NSNumber numberWithBool:valve3], nil];
}

- (void)addFingering:(NSArray *)fingering forNote:(int)note {
	//relict; not absolutely necessary
	[fingeringsForPitches addObject: fingering];
}

@end
