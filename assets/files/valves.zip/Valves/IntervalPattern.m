//
//  IntervalPattern.m
//  Valves
//
//  Created by Florian Thalmann on 3/6/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "IntervalPattern.h"


@implementation IntervalPattern

- (void)addInterval:(NSInteger)interval {
	[self addObject:interval];
}

- (void)removeLastInterval {
	[self removeLastObject];
}

@end
