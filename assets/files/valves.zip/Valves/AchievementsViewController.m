//
//  AchievementsViewController.m
//  Valves
//
//  Created by Florian Thalmann on 3/15/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "AchievementsViewController.h"
#import "Achievement.h"
#import "VAppDelegate.h"

@implementation AchievementsViewController

@synthesize parentController;

#define LABEL_TAG 1
#define VALUE_TAG 2
#define APPLE_TEXT_COLOR [UIColor colorWithRed:0.3 green:0.4 blue:0.6 alpha:1];

- (id)initWithParentController:(UITableViewController *)parent {
	[super init];
    // Override initWithStyle: if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
    parentController = parent;
	achievements = [[AchievementList alloc] initWithDatabase:[VAppDelegate database]];
    return self;
}

/*
 - (id)initWithStyle:(UITableViewStyle)style {
 // Override initWithStyle: if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
 if (self = [super initWithStyle:style]) {
 }
 return self;
 }
 */

/*
 // Implement viewDidLoad to do additional setup after loading the view.
 - (void)viewDidLoad {
 [super viewDidLoad];
 }
 */


- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [achievements.achievements count];
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[[UITableViewCell alloc] initWithFrame:CGRectZero reuseIdentifier:CellIdentifier] autorelease];
    }
	
	Achievement *cellAchievement =[achievements.achievements objectAtIndex:indexPath.row];
	[cell.contentView addSubview:[self createNameLabel:[cellAchievement name]]];
	[cell.contentView addSubview:[self createValueLabel:[NSString stringWithFormat:@"%f", [cellAchievement value]]]];
	
    return cell;
}

- (UILabel *)createNameLabel:(NSString *)name {
	UILabel *label = [[[UILabel alloc] initWithFrame:CGRectMake(8.0, 10.0, 220.0, 27.0)] autorelease];
	label.numberOfLines = 2;
	label.tag = LABEL_TAG;
	label.textColor = [UIColor blackColor];
	label.font = [UIFont boldSystemFontOfSize:12];
	label.autoresizingMask = UIViewAutoresizingFlexibleRightMargin | UIViewAutoresizingFlexibleHeight;
	label.text = name;
	return label;
}

- (UILabel *)createValueLabel:(NSString *)name {
	UILabel *label = [[[UILabel alloc] initWithFrame:CGRectMake(228.0, 10.0, 75.0, 27.0)] autorelease];
	label.numberOfLines = 2;
	label.tag = VALUE_TAG;
	label.textAlignment = UITextAlignmentRight;
	label.textColor = APPLE_TEXT_COLOR;
	label.font = [UIFont systemFontOfSize:15];
	label.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
	label.text = name;
	return label;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
}

/*
 - (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
 }
 */

/*
 - (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
 
 if (editingStyle == UITableViewCellEditingStyleDelete) {
 }
 if (editingStyle == UITableViewCellEditingStyleInsert) {
 }
 }
 */

/*
 - (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
 return YES;
 }
 */

/*
 - (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
 }
 */

/*
 - (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
 return YES;
 }
 */


/*
 - (void)viewWillAppear:(BOOL)animated {
 [super viewWillAppear:animated];
 }
 */
/*
 - (void)viewDidAppear:(BOOL)animated {
 [super viewDidAppear:animated];
 }
 */
/*
 - (void)viewWillDisappear:(BOOL)animated {
 }
 */
/*
 - (void)viewDidDisappear:(BOOL)animated {
 }
 */
/*
 - (void)didReceiveMemoryWarning {
 [super didReceiveMemoryWarning];
 }
 */

- (void)dealloc {
    [super dealloc];
}


@end

