//
//  Scale.h
//  Valves
//
//  Created by Florian Thalmann on 3/13/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface Scale : NSObject {
	NSString *notePattern;
	int root;
	int interval;
	int numberOfIterations;
	NSString *playMode;
	NSArray *pitches;
}

@property (nonatomic, retain) NSString *notePattern;
@property (nonatomic, assign) int root;
@property (nonatomic, assign) int interval;
@property (nonatomic, assign) int numberOfIterations;
@property (nonatomic, retain) NSString *playMode;
@property (nonatomic, retain) NSArray *pitches;

- (id)initWithNotePattern:(NSString *)aNotePattern root:(int)aRoot interval:(int)anInterval
				 numberOfIterations:(int)aNumberOfIterations playMode:(NSString *)aPlayMode;
- (void)generate;
- (void)appendDescendingMovement:(NSMutableArray *)pitchArray;
- (NSArray *)parseIntegers:(NSString *)numeralString;

@end
