//
//  ScaleGenerator.h
//  Valves
//
//  Created by Florian Thalmann on 11/2/08.
//  Copyright 2008 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SelectableProperty.h"
#import "Scale.h"

@interface ScaleProperties : NSObject {
	NSMutableArray *properties;
	int lowestNote;
	int highestNote;
}

@property (nonatomic, assign) NSMutableArray *properties;

- (SelectableProperty *)initNotePatternProperty;
- (SelectableProperty *)initBaseNoteProperty;
- (SelectableProperty *)initIntervalProperty;
- (SelectableProperty *)initIterationsProperty;
- (SelectableProperty *)initPlayModeProperty;
- (Scale *)scale;

@end
