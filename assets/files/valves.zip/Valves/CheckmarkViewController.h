//
//  CheckmarkViewController.h
//  Valves
//
//  Created by Florian Thalmann on 11/10/08.
//  Copyright 2008 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SelectableProperty.h"

@interface CheckmarkViewController : UITableViewController {
	SelectableProperty *property;
	UITableViewController *parentController;
}

@property (readwrite, retain) SelectableProperty *property;
@property (readwrite, retain) UITableViewController *parentController;

- (id)initWithParentController:(UITableViewController *)parent;

@end
