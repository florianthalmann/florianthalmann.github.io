//
//  Score.h
//  Valves
//
//  Created by Florian Thalmann on 3/13/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface Score : NSObject {
	int primaryKey;
	double bpm;
	double precision;
	NSDate *date;
}

@property (nonatomic, assign) int primaryKey;
@property (nonatomic, assign) double bpm;
@property (nonatomic, assign) double precision;
@property (nonatomic, retain) NSDate *date;

- (id)initWithPrimaryKey:(int)aPrimaryKey andBPM:(double)aBPM andPrecision:(double)aPrecision andDate:(NSDate *)aDate;
- (id)initWithBPM:(double)aBPM andPrecision:(double)aPrecision andDate:(NSDate *)aDate;

@end
