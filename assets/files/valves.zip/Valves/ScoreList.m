//
//  ScoreList.m
//  Valves
//
//  Created by Florian Thalmann on 3/13/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "ScoreList.h"

static sqlite3_stmt *init_statement = nil;
static sqlite3_stmt *update_statement = nil;
static sqlite3_stmt *delete_statement = nil;
static sqlite3_stmt *insert_statement = nil;

@implementation ScoreList

- (id)initWithScale:(Scale *)aScale database:(sqlite3 *)aDatabase {
	
	if (self = [super init]) {
        scale = aScale;
        database = aDatabase;
		scores = [[NSMutableArray alloc] init];
		
        // Compile the query for retrieving score data.
        if (init_statement == nil) {
            // Note the '?' at the end of the query. This is a parameter which can be replaced by a bound variable.
            // This is a great way to optimize because frequently used queries can be compiled once, then with each
            // use new variable values can be bound to placeholders.
            const char *sql = "SELECT pk, bpm, precision, date FROM scores WHERE note_pattern=? AND root=? AND interval=? AND iterations=? AND play_mode=?";
            if (sqlite3_prepare_v2(database, sql, -1, &init_statement, NULL) != SQLITE_OK) {
                NSAssert1(0, @"Error: failed to prepare statement with message '%s'.", sqlite3_errmsg(database));
            }
        }
        // For this query, we bind the primary key to the first (and only) placeholder in the statement.
        // Note that the parameters are numbered from 1, not from 0.
		sqlite3_bind_text(init_statement, 1, [[scale notePattern] UTF8String], -1, SQLITE_TRANSIENT);
		sqlite3_bind_int(init_statement, 2, [scale root]);
		sqlite3_bind_int(init_statement, 3, [scale interval]);
		sqlite3_bind_int(init_statement, 4, [scale numberOfIterations]);
		sqlite3_bind_text(init_statement, 5, [[scale playMode] UTF8String], -1, SQLITE_TRANSIENT);
		
		while (sqlite3_step(init_statement) == SQLITE_ROW) {
			int currentPK = sqlite3_column_int(init_statement, 0);
			double currentBPM = sqlite3_column_double(init_statement, 1);
			double currentPrecision = sqlite3_column_double(init_statement, 2);
			NSDate *currentDate = [[NSDate alloc] initWithTimeIntervalSinceReferenceDate: sqlite3_column_double(init_statement, 3)];
			
			// We avoid the alloc-init-autorelease pattern here because we are in a tight loop and
			// autorelease is slightly more expensive than release. This design choice has nothing to do with
			// actual memory management - at the end of this block of code, all the book objects allocated
			// here will be in memory regardless of whether we use autorelease or release, because they are
			// retained by the books array.
			Score *score = [[Score alloc] initWithPrimaryKey:currentPK andBPM:currentBPM andPrecision:currentPrecision andDate:currentDate];
			//[currentDate release];
			[scores addObject:score];
			//[score release];
		}
		
        // Reset the statement for future reuse.
        sqlite3_reset(init_statement);
    }
    return self;
}


- (BOOL)updateScoreWithBPM:(double)bpm andPrecision:(double)precision {
	NSDate *now = [[NSDate alloc] init];
	int precisionClass = precision/10;
	BOOL precisionClassAlreadyExists = NO;
	BOOL newRecord = NO;
	
	for (int i = [scores count]-1; i >= 0; i--) {
		Score *currentScore = [scores objectAtIndex:i];
		BOOL isCanditate = bpm > currentScore.bpm && precisionClass >= 7;
		int currentPrecisionClass = currentScore.precision/10;
		if (precisionClass == currentPrecisionClass) {
			precisionClassAlreadyExists = YES;
			if (isCanditate) {	
				newRecord = YES;
				currentScore.bpm = bpm;
				currentScore.precision = precision;
				currentScore.date = now;
				[self updateScoreInDB:currentScore];
			}
		} else if (precisionClass > currentPrecisionClass && isCanditate) {
			[scores removeObject:currentScore];
			[self deleteScoreFromDB:currentScore];
		}
	}
	if (!precisionClassAlreadyExists && precisionClass >= 7) {
		newRecord = YES;
		Score *newScore = [[Score alloc] initWithBPM:bpm andPrecision:precision andDate:now];
		[scores addObject:newScore];
		int primaryKey = [self insertScoreIntoDB: newScore];
		newScore.primaryKey = primaryKey;
	}
	return newRecord;
}


- (void)updateScoreInDB:(Score *)score {
	if (update_statement == nil) {
		const char *sql = "UPDATE scores SET bpm=?, precision=?, date=? WHERE pk=?";
		if (sqlite3_prepare_v2(database, sql, -1, &update_statement, NULL) != SQLITE_OK) {
			NSAssert1(0, @"Error: failed to prepare statement with message '%s'.", sqlite3_errmsg(database));
		}
	}
	
	sqlite3_bind_double(update_statement, 1, [score bpm]);
	sqlite3_bind_double(update_statement, 2, [score precision]);
	sqlite3_bind_double(update_statement, 3, [[score date] timeIntervalSinceReferenceDate]);
	sqlite3_bind_int(update_statement, 4, [score primaryKey]);
	
	if (sqlite3_step(update_statement) != SQLITE_DONE) {
		NSAssert1(0, @"Error: failed to update score with message '%s'.", sqlite3_errmsg(database));
	}
	
	sqlite3_reset(update_statement);
}


- (void)deleteScoreFromDB:(Score *)score {
	if (delete_statement == nil) {
		const char *sql = "DELETE FROM scores WHERE pk=?";
		if (sqlite3_prepare_v2(database, sql, -1, &delete_statement, NULL) != SQLITE_OK) {
			NSAssert1(0, @"Error: failed to prepare statement with message '%s'.", sqlite3_errmsg(database));
		}
	}
	
	int primaryKey = [score primaryKey];
	sqlite3_bind_int(delete_statement, 1, primaryKey);
	
	if (sqlite3_step(delete_statement) != SQLITE_DONE) {
		NSAssert1(0, @"Error: failed to delete score with message '%s'.", sqlite3_errmsg(database));
	}
	
	sqlite3_reset(delete_statement);
}


- (NSInteger)insertScoreIntoDB:(Score *)score {
	if (insert_statement == nil) {
		const char *sql = "INSERT INTO scores (note_pattern, root, interval, iterations, play_mode, bpm, precision, date) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
		if (sqlite3_prepare_v2(database, sql, -1, &insert_statement, NULL) != SQLITE_OK) {
			NSAssert1(0, @"Error: failed to prepare statement with message '%s'.", sqlite3_errmsg(database));
		}
	}
	
	sqlite3_bind_text(insert_statement, 1, [[scale notePattern] UTF8String], -1, SQLITE_TRANSIENT);
	sqlite3_bind_int(insert_statement, 2, [scale root]);
	sqlite3_bind_int(insert_statement, 3, [scale interval]);
	sqlite3_bind_int(insert_statement, 4, [scale numberOfIterations]);
	sqlite3_bind_text(insert_statement, 5, [[scale playMode] UTF8String], -1, SQLITE_TRANSIENT);
	sqlite3_bind_double(insert_statement, 6, [score bpm]);
	sqlite3_bind_double(insert_statement, 7, [score precision]);
	sqlite3_bind_double(insert_statement, 8, [[score date] timeIntervalSinceReferenceDate]);
	
	int success = sqlite3_step(insert_statement);
	sqlite3_reset(insert_statement);
	if (success != SQLITE_ERROR) {
		return sqlite3_last_insert_rowid(database);
	}
	NSAssert1(0, @"Error: failed to update score with message '%s'.", sqlite3_errmsg(database));
	return -1;
}


- (NSString*)stringValue {
	NSString *scoreString = @"";
	for (Score *score in scores) {
		scoreString = [scoreString stringByAppendingString:
					   [NSString stringWithFormat:@"BPM: %f\nPrecision: %f\nDate: %@\n\n", [score bpm],
						[score precision], [[score date] description]]];
	}
	return scoreString;
}

@end
