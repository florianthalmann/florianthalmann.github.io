//
//  AchievementList.m
//  Valves
//
//  Created by Florian Thalmann on 3/15/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "AchievementList.h"
#import "Achievement.h"


@implementation AchievementList

@synthesize achievements;

- (id)initWithDatabase:(sqlite3 *)db {
	if (self = [super init]) {
		database = db;
		[self initAchievements];
	}
	return self;
}
		

- (void)initAchievements {
	achievements = [[NSMutableArray alloc] init];
	[self initSlonimskyTritoneOneNote];
	[self initSlonimskyTritoneTwoNotes];
	[self initSlonimskyTritoneThreeNotes];
}


- (void)initSlonimskyTritoneOneNote {
	NSArray *notePatterns = [[NSArray alloc] initWithObjects:@"01", @"02", @"03", @"04", @"05", nil];
	NSArray *roots = [[NSArray alloc] initWithObjects:[NSNumber numberWithInt:52], [NSNumber numberWithInt:53], [NSNumber numberWithInt:54], nil];
	NSArray *intervals = [[NSArray alloc] initWithObjects:[NSNumber numberWithInt:6], nil];
	NSArray *iterations = [[NSArray alloc] initWithObjects:[NSNumber numberWithInt:5], nil];
	NSArray *playModes = [[NSArray alloc] initWithObjects:@"012345", nil];
	[achievements addObject:[[Achievement alloc] 
							 initWithName:@"Tritone progression, interpolation of one note, 90%, F#/G/Ab"
							 andNotePatterns:notePatterns andRoots:roots andIntervals:intervals
							 andIterations:iterations andPlayModes:playModes andMinimumPrecision:90
							 andRequiredResults:15 andDatabase:database]];
}

- (void)initSlonimskyTritoneTwoNotes {
	NSArray *notePatterns = [[NSArray alloc] initWithObjects:@"012", @"013", @"014", @"015", @"023", @"024", @"025", @"034", @"035", @"045", nil];
	NSArray *roots = [[NSArray alloc] initWithObjects:[NSNumber numberWithInt:52], [NSNumber numberWithInt:53], [NSNumber numberWithInt:54], nil];
	NSArray *intervals = [[NSArray alloc] initWithObjects:[NSNumber numberWithInt:6], nil];
	NSArray *iterations = [[NSArray alloc] initWithObjects:[NSNumber numberWithInt:5], nil];
	NSArray *playModes = [[NSArray alloc] initWithObjects:@"012345", nil];
	[achievements addObject:[[Achievement alloc] 
							 initWithName:@"Tritone progression, interpolation of two notes, 90%, F#/G/Ab"
							 andNotePatterns:notePatterns andRoots:roots andIntervals:intervals
							 andIterations:iterations andPlayModes:playModes andMinimumPrecision:90
							 andRequiredResults:30 andDatabase:database]];
}

- (void)initSlonimskyTritoneThreeNotes {
	NSArray *notePatterns = [[NSArray alloc] initWithObjects:@"0123", @"0124", @"0125", @"0134", @"0135", @"0145", @"0234", @"0235", @"0245", @"0345", nil];
	NSArray *roots = [[NSArray alloc] initWithObjects:[NSNumber numberWithInt:52], [NSNumber numberWithInt:53], [NSNumber numberWithInt:54], nil];
	NSArray *intervals = [[NSArray alloc] initWithObjects:[NSNumber numberWithInt:6], nil];
	NSArray *iterations = [[NSArray alloc] initWithObjects:[NSNumber numberWithInt:5], nil];
	NSArray *playModes = [[NSArray alloc] initWithObjects:@"012345", nil];
	[achievements addObject:[[Achievement alloc] 
							 initWithName:@"Tritone progression, interpolation of three notes, 90%, F#/G/Ab"
							 andNotePatterns:notePatterns andRoots:roots andIntervals:intervals
							 andIterations:iterations andPlayModes:playModes andMinimumPrecision:90
							 andRequiredResults:30 andDatabase:database]];
}

- (void)initTwoNoteSequences {
	NSArray *notePatterns = [[NSArray alloc] initWithObjects:@"01", @"02", @"03", @"04", @"05", nil];
	NSArray *roots = [[NSArray alloc] initWithObjects:[NSNumber numberWithInt:52], nil];
	NSArray *intervals = [[NSArray alloc] initWithObjects:[NSNumber numberWithInt:1], nil];
	NSArray *iterations = [[NSArray alloc] initWithObjects:[NSNumber numberWithInt:12], nil];
	NSArray *playModes = [[NSArray alloc] initWithObjects:@"012345", nil];
	[achievements addObject:[[Achievement alloc] 
							 initWithName:@"Two-note sequences over an octave, 90%, F#"
							 andNotePatterns:notePatterns andRoots:roots andIntervals:intervals
							 andIterations:iterations andPlayModes:playModes andMinimumPrecision:90
							 andRequiredResults:5 andDatabase:database]];
}

- (void)initThreeNoteSequences {
	NSArray *notePatterns = [[NSArray alloc] initWithObjects:@"012", @"013", @"014", @"015", @"023", @"024", @"025", @"034", @"035", @"045", nil];
	NSArray *roots = [[NSArray alloc] initWithObjects:[NSNumber numberWithInt:52], nil];
	NSArray *intervals = [[NSArray alloc] initWithObjects:[NSNumber numberWithInt:1], nil];
	NSArray *iterations = [[NSArray alloc] initWithObjects:[NSNumber numberWithInt:12], nil];
	NSArray *playModes = [[NSArray alloc] initWithObjects:@"012345", nil];
	[achievements addObject:[[Achievement alloc] 
							 initWithName:@"Three-note sequences over an octave, 90%, F#"
							 andNotePatterns:notePatterns andRoots:roots andIntervals:intervals
							 andIterations:iterations andPlayModes:playModes andMinimumPrecision:90
							 andRequiredResults:10 andDatabase:database]];
}

- (void)initFourNoteSequences {
	NSArray *notePatterns = [[NSArray alloc] initWithObjects:@"0123", @"0124", @"0125", @"0134", @"0135", @"0145", @"0234", @"0235", @"0245", @"0345", nil];
	NSArray *roots = [[NSArray alloc] initWithObjects:[NSNumber numberWithInt:52], nil];
	NSArray *intervals = [[NSArray alloc] initWithObjects:[NSNumber numberWithInt:1], nil];
	NSArray *iterations = [[NSArray alloc] initWithObjects:[NSNumber numberWithInt:12], nil];
	NSArray *playModes = [[NSArray alloc] initWithObjects:@"012345", nil];
	[achievements addObject:[[Achievement alloc] 
							 initWithName:@"Four-note sequences over an octave, 90%, F#"
							 andNotePatterns:notePatterns andRoots:roots andIntervals:intervals
							 andIterations:iterations andPlayModes:playModes andMinimumPrecision:90
							 andRequiredResults:10 andDatabase:database]];
}

@end
