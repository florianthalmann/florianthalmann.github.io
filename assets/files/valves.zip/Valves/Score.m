//
//  Score.m
//  Valves
//
//  Created by Florian Thalmann on 3/13/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "Score.h"


@implementation Score

@synthesize primaryKey;
@synthesize bpm;
@synthesize precision;
@synthesize date;

- (id)initWithPrimaryKey:(int)aPrimaryKey andBPM:(double)aBPM andPrecision:(double)aPrecision andDate:(NSDate *)aDate {
	if (self = [super init]) {
		primaryKey = aPrimaryKey;
		bpm = aBPM;
		precision = aPrecision;
		date = aDate;
	}
	return self;
}

- (id)initWithBPM:(double)aBPM andPrecision:(double)aPrecision andDate:(NSDate *)aDate {
	if (self = [super init]) {
		bpm = aBPM;
		precision = aPrecision;
		date = aDate;
	}
	return self;
}

@end
