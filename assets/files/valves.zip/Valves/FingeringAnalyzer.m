//
//  FingeringAnalyzer.m
//  Valves
//
//  Created by Florian Thalmann on 3/10/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "FingeringAnalyzer.h"
#import "MainViewController.h"
#import "Fingerings.h"

@implementation FingeringAnalyzer


- (id)initWithScale:(NSArray *)newScale parentController:(MainViewController *)controller {
	self = [super init];
	scale = newScale;
	removedV0InTheBeginning = 0;
	[self initScaleInfo];
	parentController = controller;
	[self reset];
	requiredFingeringsForAnalysis = 4;
	accuracy = 2;
	return self;
}

- (void)initScaleInfo {
	successiveFingerings = [[NSMutableArray alloc] initWithArray:scale];
	relativeDurations = [[NSMutableArray alloc] init];
	
	//remove v0 at beginning
	while ([scale objectAtIndex:removedV0InTheBeginning] == parentController.fingerings.v0) {
		removedV0InTheBeginning++;
	}
	
	//remove equal successive fingerings
	NSArray *previousFingering = nil;
	int numberOfSuccessiveFingerings = 0;
	for (int i = [scale count]-1; i >= 0; i--) {
		if ([scale objectAtIndex:i] == previousFingering) {
			[successiveFingerings removeObjectAtIndex:i];
			numberOfSuccessiveFingerings++;
		} else {
			if (i < [scale count]-1) {
				[relativeDurations insertObject:[NSNumber numberWithInt:numberOfSuccessiveFingerings] atIndex:0];
			}
			previousFingering = [scale objectAtIndex:i];
			numberOfSuccessiveFingerings = 1;
		}
	}
	[relativeDurations insertObject:[NSNumber numberWithInt:numberOfSuccessiveFingerings] atIndex:0];
}

- (void)reset {
	numberOfFingeringsPlayed = 0;
	playedFingerings = [[NSMutableArray alloc] init];
	playedDurations = [[NSMutableArray alloc] init];
	lastIndexOfAnalysis = -1;
}

- (void)fingeringPlayed:(NSArray *)fingering forTime:(double)timeInterval {
	[playedFingerings addObject:fingering];
	[playedDurations addObject:[NSNumber numberWithDouble:(timeInterval)]];
	[self analyze];
}

- (void)analyze {
	if ([playedFingerings count] > requiredFingeringsForAnalysis) {
		[self eliminateGlitches];
		if ([self rightFingeringsPlayed]) {
			lastIndexOfAnalysis = [playedFingerings count]-1;
		} else {
			[parentController showPlayingMistake];
		}
	}
	if ([playedFingerings count] == [successiveFingerings count]-1) {
		//right when last note attacked. last note not included in analysis.
		[self updateDurations];
		[self postFinalAnalysis];
	}
}


- (void)eliminateGlitches {
	double glitchDuration = [self getGlitchDuration];
	for (int i = [playedFingerings count]-1; i > lastIndexOfAnalysis; i--) {
		double currentDuration = [[playedDurations objectAtIndex:i] doubleValue];
		if (currentDuration < glitchDuration) {
			[playedFingerings removeObjectAtIndex:i];
			[playedDurations removeObjectAtIndex:i];
			
			if (i > 0) {
				//add time of removed fingering to previous fingering to keep continuity
				double previousDuration = [[playedDurations objectAtIndex:i-1] doubleValue];
				previousDuration += currentDuration;
				[playedDurations replaceObjectAtIndex:i-1 withObject:[NSNumber numberWithDouble:previousDuration]];
			}
		}
	}
}

- (double)getGlitchDuration {
	double sum = 0;
	for (int i = 0; i < [playedFingerings count]; i++) {
		sum += [[playedDurations objectAtIndex:i] doubleValue];
	}
	return sum/[playedFingerings count]/accuracy;
}


- (BOOL)rightFingeringsPlayed {
	for (int i = [playedFingerings count]-1; i > lastIndexOfAnalysis; i--) {
		if ([playedFingerings objectAtIndex:i] != [successiveFingerings objectAtIndex:i]) {
			return false;
		}
	}
	return true;
}


- (void)updateDurations {
	for (int i = [playedDurations count]-1; i >= 0; i--) { 
		int currentRelativeDuration = [[relativeDurations objectAtIndex:i] intValue];
		if (currentRelativeDuration > 1) {
			NSNumber *currentDuration = [NSNumber numberWithDouble:[[playedDurations objectAtIndex:i] doubleValue]/currentRelativeDuration];
			[playedDurations replaceObjectAtIndex:i withObject:currentDuration];
			for (int j = 1; j < currentRelativeDuration; j++) {
				[playedDurations insertObject:currentDuration atIndex:i];
			}
		}
	}
}


- (void)postFinalAnalysis {
	//speed
	double totalTime = 0;
	for (NSNumber *currentDuration in playedDurations) {
		totalTime += [currentDuration doubleValue];
	}
	double n = [scale count]-1-removedV0InTheBeginning;
	double averageTime = totalTime/n;
	double bpmValue = 60/(averageTime*4); //each time interval is taken as a sixteenth
	
	//precision
	double standardDeviation = 0;
	for (NSNumber *currentDuration in playedDurations) {
		standardDeviation += pow([currentDuration doubleValue]-averageTime, 2);
	}
	standardDeviation = sqrt(standardDeviation/(n-1));
	
	double precision = (1-(standardDeviation/averageTime))*100;
	
	[parentController showSuccessfulPlayingWithBPM:bpmValue andPrecision:precision];
}

@end
