//
//  AchievementList.h
//  Valves
//
//  Created by Florian Thalmann on 3/15/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <sqlite3.h>


@interface AchievementList : NSObject {
	NSMutableArray *achievements;
	sqlite3 *database;
}

@property (nonatomic, retain) NSMutableArray *achievements;

- (id)initWithDatabase:(sqlite3 *)db;
- (void)initAchievements;
- (void)initSlonimskyTritoneOneNote;
- (void)initSlonimskyTritoneTwoNotes;
- (void)initSlonimskyTritoneThreeNotes;

@end
