//
//  SettingsViewController.m
//  Valves
//
//  Created by Florian Thalmann on 11/11/08.
//  Copyright 2008 __MyCompanyName__. All rights reserved.
//

#import "SettingsViewController.h"
#import "AchievementsViewController.h"


@implementation SettingsViewController

@synthesize options;
@synthesize rootViewController;
@synthesize scaleProperties;

#define LABEL_TAG 1
#define VALUE_TAG 2
#define APPLE_TEXT_COLOR [UIColor colorWithRed:0.3 green:0.4 blue:0.6 alpha:1];

- (void)viewDidLoad {
    [super viewDidLoad];
	
	self.title = @"Settings";
	
    UIBarButtonItem *doneButton = [[UIBarButtonItem alloc]
								   initWithBarButtonSystemItem:UIBarButtonSystemItemDone
								   target:self.rootViewController
								   action:@selector(toggleView)];
	
	self.navigationItem.rightBarButtonItem = doneButton;
	[doneButton release];
	
    // Uncomment the following line to add the Edit button to the navigation bar.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 2;
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (section == 0) {
		return [scaleProperties.properties count];
	} else {
		return 1;
	}
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[[UITableViewCell alloc] initWithFrame:CGRectZero] autorelease];
    }
	
	if (indexPath.section == 1) {
		[cell.contentView addSubview:[self createNameLabel:@"Achievements"]];
	} else {
		SelectableProperty *cellProperty =[scaleProperties.properties objectAtIndex:indexPath.row];
		[cell.contentView addSubview:[self createNameLabel:[cellProperty name]]];
		[cell.contentView addSubview:[self createValueLabel:[cellProperty selectedOption]]];
	}
		
	cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    
    // Set up the cell
    return cell;
}


- (UILabel *)createNameLabel:(NSString *)name {
	UILabel *label = [[[UILabel alloc] initWithFrame:CGRectMake(10.0, 9.0, 120.0, 24.0)] autorelease];
	label.tag = LABEL_TAG;
	label.textColor = [UIColor blackColor];
	label.font = [UIFont boldSystemFontOfSize:label.font.pointSize];
	label.autoresizingMask = UIViewAutoresizingFlexibleRightMargin | UIViewAutoresizingFlexibleHeight;
	label.text = name;
	return label;
}

- (UILabel *)createValueLabel:(NSString *)name {
	UILabel *label = [[[UILabel alloc] initWithFrame:CGRectMake(125.0, 9.0, 188.0, 24.0)] autorelease];
	label.tag = VALUE_TAG;
	label.textAlignment = UITextAlignmentRight;
	label.textColor = APPLE_TEXT_COLOR;
	label.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
	label.text = name;
	return label;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
	if (indexPath.section == 1) {
		AchievementsViewController *achievementsViewController =
			[[AchievementsViewController alloc] initWithParentController:self];
		achievementsViewController.title = @"Achievements";
		[[self navigationController] pushViewController:achievementsViewController animated:YES];
		[achievementsViewController release];
	} else {
		CheckmarkViewController *checkmarkViewController = [[CheckmarkViewController alloc] initWithParentController:self];
		
		checkmarkViewController.property = [scaleProperties.properties objectAtIndex:indexPath.row];
		checkmarkViewController.title = [options objectAtIndex:indexPath.row];
		[[self navigationController] pushViewController:checkmarkViewController animated:YES];
		[checkmarkViewController release];
	}
}


- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning]; // Releases the view if it doesn't have a superview
    // Release anything that's not essential, such as cached data
}


- (void)dealloc {
    [super dealloc];
}


@end

